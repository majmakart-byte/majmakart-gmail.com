/* =============================================
   MAJMAKART — Complete Theme JS
   Cart · Search · Dark Mode · Animations · All
   ============================================= */
'use strict';

/* ---------- UTILS ---------- */
const $ = (s, c = document) => c.querySelector(s);
const $$ = (s, c = document) => [...c.querySelectorAll(s)];
const on = (el, ev, fn, opts) => el && el.addEventListener(ev, fn, opts);
function fmt(cents) {
  const v = parseInt(cents, 10) / 100;
  return '₹' + (v % 1 === 0 ? v.toLocaleString('en-IN') : v.toFixed(2));
}
function debounce(fn, ms) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}
function throttle(fn, ms) {
  let last = 0; return (...a) => { const now = Date.now(); if (now - last >= ms) { last = now; fn(...a); } };
}

/* ---------- TOAST ---------- */
function showToast(msg, dur = 3000) {
  const el = $('#SiteToast');
  if (!el) return;
  el.textContent = msg;
  el.classList.add('show');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), dur);
}

/* ---------- OVERLAY ---------- */
function openOverlay()  { $('#SiteOverlay')?.classList.add('open'); document.body.style.overflow = 'hidden'; }
function closeOverlay() { $('#SiteOverlay')?.classList.remove('open'); document.body.style.overflow = ''; }

/* =============================================
   MJK GLOBAL NAMESPACE
   ============================================= */
window.MJK = window.MJK || {};
window.MJK.config = window.MJK.config || {};

MJK.closeAll = function () {
  Cart.close();
  closeOverlay();
  $('#MobilePanel')?.classList.remove('open');
  $('.ham-btn')?.classList.remove('open');
  $('.search-bar')?.classList.remove('open');
};

/* =============================================
   CART
   ============================================= */
const Cart = {
  freeShip: 59900,

  init() {
    this.freeShip = MJK.config.freeShip || 59900;

    // Close button
    on($('#CartDrawer'), 'click', e => {
      if (e.target.closest('.cdr-close') || e.target.id === 'CartDrawer') return;
    });
    on(document, 'click', e => {
      if (e.target.closest('.cdr-close')) this.close();
    });

    // Qty buttons in drawer
    on($('#CdrBody'), 'click', e => {
      const inc = e.target.closest('[data-inc]');
      const dec = e.target.closest('[data-dec]');
      const rem = e.target.closest('[data-rem]');
      if (inc) this.change(inc.dataset.inc, 1);
      if (dec) this.change(dec.dataset.dec, -1);
      if (rem) this.remove(rem.dataset.rem);
    });

    // Cart page qty
    on(document, 'click', e => {
      const inc = e.target.closest('[data-page-inc]');
      const dec = e.target.closest('[data-page-dec]');
      const rem = e.target.closest('[data-page-rem]');
      if (inc) this.pageChange(inc.dataset.pageInc, 1);
      if (dec) this.pageChange(dec.dataset.pageDec, -1);
      if (rem) this.pageRemove(rem.dataset.pageRem);
    });

    // ATC buttons anywhere on page
    on(document, 'click', e => {
      const btn = e.target.closest('[data-atc]');
      if (btn) { e.preventDefault(); this.add(btn); }
    });

    this.refresh(false);
  },

  open() {
    const d = $('#CartDrawer');
    if (!d) return;
    d.classList.add('open');
    d.setAttribute('aria-hidden', 'false');
    openOverlay();
    this.refresh(true);
  },

  close() {
    const d = $('#CartDrawer');
    if (!d) return;
    d.classList.remove('open');
    d.setAttribute('aria-hidden', 'true');
    closeOverlay();
  },

  async refresh(open = false) {
    try {
      const r = await fetch('/cart.js', { headers: { Accept: 'application/json' } });
      const cart = await r.json();
      this.renderDrawer(cart);
      this.updateBadges(cart.item_count);
      this.updateFreeShip(cart.total_price);
      if (open) {
        const foot = $('#CdrFoot');
        if (foot) foot.style.display = cart.items.length ? 'block' : 'none';
      }
    } catch {}
  },

  updateBadges(count) {
    $$('[id="cart-count"], .cart-badge, #BnBadge, #CdrCount').forEach(el => {
      if (el.id === 'BnBadge') {
        el.textContent = count;
        el.style.display = count > 0 ? 'grid' : 'none';
      } else if (el.classList.contains('cart-badge')) {
        el.textContent = count;
        el.classList.toggle('visible', count > 0);
      } else {
        el.textContent = count;
      }
    });
  },

  updateFreeShip(total) {
    const msg  = $('#CdrFsMsg');
    const fill = $('#CdrFsFill');
    if (!msg || !fill) return;
    const pct = Math.min((total / this.freeShip) * 100, 100);
    fill.style.width = pct + '%';
    if (total >= this.freeShip) {
      msg.innerHTML = '🎉 <strong>Free delivery unlocked!</strong>';
    } else {
      msg.innerHTML = `<strong>${fmt(this.freeShip - total)}</strong> more for free delivery`;
    }
  },

  renderDrawer(cart) {
    const body = $('#CdrBody');
    const foot = $('#CdrFoot');
    const sub  = $('#CdrSubtotal');
    if (sub) sub.textContent = fmt(cart.total_price);
    if (!body) return;

    if (!cart.items.length) {
      body.innerHTML = `<div class="cdr-empty">
        <span class="cdr-empty-icon">🛒</span>
        <p>Your cart is empty</p>
        <a href="/collections/all" class="btn btn-primary btn-sm" onclick="MJK.closeAll()">Start Shopping</a>
      </div>`;
      if (foot) foot.style.display = 'none';
      return;
    }

    if (foot) foot.style.display = 'block';

    body.innerHTML = cart.items.map(item => `
      <div class="cdr-item" data-key="${item.key}">
        ${item.image
          ? `<img class="cdr-item-img" src="${item.image}" alt="${item.title}" loading="lazy" width="72" height="72">`
          : `<div class="cdr-item-img-ph" aria-hidden="true">${this.emoji(item.product_type)}</div>`}
        <div>
          <p class="cdr-item-name">${item.product_title}</p>
          ${item.variant_title && item.variant_title !== 'Default Title'
            ? `<p class="cdr-item-variant">${item.variant_title}</p>` : ''}
          <div class="cdr-item-row">
            <span class="cdr-item-price">${fmt(item.line_price)}</span>
            <div class="cdr-qty" role="group" aria-label="Quantity">
              <button class="cdr-qty-btn" data-dec="${item.key}" aria-label="Decrease">−</button>
              <span class="cdr-qty-num">${item.quantity}</span>
              <button class="cdr-qty-btn" data-inc="${item.key}" aria-label="Increase">+</button>
            </div>
          </div>
          <button class="cdr-remove" data-rem="${item.key}">Remove</button>
        </div>
      </div>`).join('');
  },

  emoji(type = '') {
    const m = { 'Smart Home': '🏠', Gadgets: '🔧', Health: '💪', Travel: '✈️', Kitchen: '🍳' };
    return m[type] || '📦';
  },

  async add(btn) {
    const id = btn.dataset.atc || btn.dataset.variantId;
    if (!id) return;
    const form = btn.closest('form, .product-page, section');
    const qty  = parseInt($('[data-qty-input]', form)?.value || 1);
    const orig = btn.innerHTML;
    btn.innerHTML = '<span class="spinner"></span>';
    btn.classList.add('loading');
    btn.disabled = true;
    try {
      const r = await fetch('/cart/add.js', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ id: parseInt(id), quantity: qty })
      });
      const item = await r.json();
      if (item.status) throw new Error(item.description);
      btn.innerHTML = '✓ Added!';
      btn.classList.add('added');
      btn.classList.remove('loading');
      btn.disabled = false;
      showToast(`✓ ${item.product_title} added to cart`);
      this.refresh(false);
      setTimeout(() => this.open(), 350);
      setTimeout(() => { btn.innerHTML = orig; btn.classList.remove('added'); }, 2200);
    } catch (err) {
      btn.innerHTML = orig;
      btn.classList.remove('loading');
      btn.disabled = false;
      showToast('⚠️ ' + (err.message || 'Could not add to cart'));
    }
  },

  async change(key, delta) {
    const item = $(`.cdr-item[data-key="${key}"]`);
    const num  = item ? parseInt($('.cdr-qty-num', item).textContent) : 1;
    const newQ = Math.max(0, num + delta);
    await fetch('/cart/change.js', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: key, quantity: newQ })
    });
    this.refresh(true);
  },

  async remove(key) {
    await fetch('/cart/change.js', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: key, quantity: 0 })
    });
    this.refresh(true);
  },

  async pageChange(key, delta) {
    const numEl = $(`[data-cart-qty="${key}"]`);
    const num   = numEl ? parseInt(numEl.textContent) : 1;
    const newQ  = Math.max(0, num + delta);
    if (numEl) numEl.textContent = newQ;
    await fetch('/cart/change.js', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: key, quantity: newQ })
    });
    setTimeout(() => window.location.reload(), 400);
  },

  async pageRemove(key) {
    await fetch('/cart/change.js', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: key, quantity: 0 })
    });
    window.location.reload();
  }
};

MJK.openCart  = () => Cart.open();
MJK.closeCart = () => Cart.close();

/* =============================================
   HEADER
   ============================================= */
function initHeader() {
  const header  = $('#SiteHeader');
  const hamBtn  = $('.ham-btn');
  const panel   = $('#MobilePanel');
  const panelClose = $('#PanelClose');

  // Scroll behaviour
  window.addEventListener('scroll', throttle(() => {
    header?.classList.toggle('scrolled', window.scrollY > 20);
    // Back to top
    $('#BackTop')?.classList.toggle('show', window.scrollY > 500);
  }, 80), { passive: true });

  // Hamburger
  on(hamBtn, 'click', () => {
    const open = panel?.classList.toggle('open');
    hamBtn.classList.toggle('open', open);
    if (open) openOverlay(); else closeOverlay();
  });
  on(panelClose, 'click', MJK.closeAll);

  // Cart icon in header
  on($('[data-cart-open]'), 'click', () => Cart.open());

  // Search
  on($('[data-search-open]'), 'click', () => toggleSearch());

  // Dark mode toggle
  $$('[data-theme-toggle]').forEach(btn => {
    on(btn, 'click', () => {
      const cur  = document.documentElement.dataset.theme;
      const next = cur === 'dark' ? 'light' : 'dark';
      document.documentElement.dataset.theme = next;
      localStorage.setItem('mjk-theme', next);
    });
  });
}

/* =============================================
   SEARCH
   ============================================= */
function toggleSearch() {
  const bar = $('.search-bar');
  if (!bar) return;
  const open = bar.classList.toggle('open');
  if (open) { bar.querySelector('input')?.focus(); openOverlay(); }
  else closeOverlay();
}

function initPredictiveSearch() {
  const input = $('[data-search-input]');
  if (!input) return;
  const results = $('#SearchResults');
  if (!results) return;

  on(input, 'input', debounce(async e => {
    const q = e.target.value.trim();
    if (!q || q.length < 2) { results.innerHTML = '<p class="text-muted" style="padding:.5rem">Type to search…</p>'; return; }
    results.innerHTML = '<div class="cdr-loading"><div class="spinner"></div></div>';
    try {
      const r = await fetch(`/search/suggest.json?q=${encodeURIComponent(q)}&resources[type]=product&resources[limit]=6`, { headers: { Accept: 'application/json' } });
      const data = await r.json();
      const items = data.resources?.results?.products || [];
      if (!items.length) { results.innerHTML = `<p class="text-muted" style="padding:.5rem">No results for "${q}"</p>`; return; }
      results.innerHTML = items.map(p => `
        <a href="${p.url}" class="sr-item" onclick="MJK.closeAll()">
          <img class="sr-img" src="${p.featured_image || ''}" alt="${p.title}" onerror="this.style.display='none'" loading="lazy" width="48" height="48">
          <div><p class="sr-name">${p.title}</p><p class="sr-price">${fmt(p.price)}</p></div>
        </a>`).join('')
        + `<a href="/search?q=${encodeURIComponent(q)}" class="sr-view-all">View all results →</a>`;
    } catch {
      results.innerHTML = '<p class="text-muted" style="padding:.5rem">Search unavailable</p>';
    }
  }, 240));

  on(input, 'keydown', e => {
    if (e.key === 'Enter' && input.value.trim()) window.location.href = `/search?q=${encodeURIComponent(input.value.trim())}`;
  });
}

/* =============================================
   SCROLL ANIMATIONS
   ============================================= */
function initAnimations() {
  if (!('IntersectionObserver' in window)) {
    $$('[data-anim]').forEach(el => el.classList.add('animated')); return;
  }
  const obs = new IntersectionObserver(entries => {
    entries.forEach(({ target, isIntersecting }) => {
      if (isIntersecting) { target.classList.add('animated'); obs.unobserve(target); }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
  $$('[data-anim]').forEach(el => obs.observe(el));
}

/* =============================================
   LAZY IMAGES
   ============================================= */
function initLazy() {
  if (!('IntersectionObserver' in window)) {
    $$('img[data-src]').forEach(img => { img.src = img.dataset.src; }); return;
  }
  const obs = new IntersectionObserver(entries => {
    entries.forEach(({ target, isIntersecting }) => {
      if (isIntersecting) {
        if (target.dataset.src) target.src = target.dataset.src;
        obs.unobserve(target);
      }
    });
  }, { rootMargin: '200px' });
  $$('img[data-src]').forEach(img => obs.observe(img));
}

/* =============================================
   PRODUCT PAGE
   ============================================= */
function initProductPage() {
  if (!$('.product-page')) return;

  // Thumbnails
  on(document, 'click', e => {
    const thumb = e.target.closest('.product-thumb');
    if (!thumb || !thumb.dataset.src) return;
    $$('.product-thumb').forEach(t => t.classList.remove('active'));
    thumb.classList.add('active');
    const mainImg = $('#MainProductImage');
    if (mainImg) { mainImg.src = thumb.dataset.src; mainImg.srcset = ''; }
  });

  // Variant options
  on(document, 'click', e => {
    const btn = e.target.closest('.option-btn');
    if (!btn) return;
    const group = btn.closest('[data-option-group]');
    $$('.option-btn', group).forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const display = $('[data-opt-val]', group);
    if (display) display.textContent = btn.dataset.value;
    updateVariantSelect();
  });

  // Qty buttons
  on(document, 'click', e => {
    const input = $('[data-qty-input]');
    if (!input) return;
    if (e.target.closest('[data-qty-plus]'))  input.value = Math.min(parseInt(input.value || 1) + 1, 99);
    if (e.target.closest('[data-qty-minus]')) input.value = Math.max(parseInt(input.value || 1) - 1, 1);
  });

  // Sticky ATC
  const addRow   = $('.product-actions-main');
  const stickyATC = $('.sticky-atc');
  if (addRow && stickyATC) {
    new IntersectionObserver(([e]) => stickyATC.classList.toggle('visible', !e.isIntersecting)).observe(addRow);
  }

  // Tabs
  on(document, 'click', e => {
    const btn = e.target.closest('.tab-btn');
    if (!btn) return;
    const tabs = btn.closest('.product-tabs');
    $$('.tab-btn', tabs).forEach(b => b.classList.remove('active'));
    $$('.tab-content', tabs).forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    $('#' + btn.dataset.tab)?.classList.add('active');
  });

  // FAQ
  on(document, 'click', e => {
    const trig = e.target.closest('.faq-trigger');
    if (!trig) return;
    const item = trig.closest('.faq-item');
    const was  = item.classList.contains('open');
    $$('.faq-item').forEach(i => i.classList.remove('open'));
    if (!was) item.classList.add('open');
  });

  // Image zoom (simple full-screen)
  on($('[data-zoom-btn]'), 'click', () => {
    const src = $('#MainProductImage')?.src;
    if (!src) return;
    const over = document.createElement('div');
    over.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.92);z-index:9999;display:grid;place-items:center;cursor:zoom-out';
    over.innerHTML = `<img src="${src}" style="max-width:92vw;max-height:92vh;object-fit:contain;border-radius:8px">`;
    over.addEventListener('click', () => over.remove());
    document.body.appendChild(over);
  });
}

function updateVariantSelect() {
  const select = $('[data-variant-select]');
  if (!select) return;
  const vals = $$('.option-btn.active').map(b => b.dataset.value);
  for (const opt of select.options) {
    if (vals.every(v => opt.text.includes(v))) { select.value = opt.value; break; }
  }
  // Update ATC button
  const atcBtn = $('[data-atc]');
  if (atcBtn && select.value) atcBtn.dataset.atc = select.value;
}

/* =============================================
   FLASH SALE TIMER
   ============================================= */
function initTimers() {
  $$('[data-countdown]').forEach(el => {
    const end = new Date(el.dataset.countdown).getTime();
    function tick() {
      const diff = end - Date.now();
      if (diff <= 0) { el.innerHTML = '<div class="timer-block"><span class="timer-num">00</span></div>'; return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      const pad = n => String(n).padStart(2, '0');
      el.innerHTML = `
        <div class="timer-block"><span class="timer-num">${pad(h)}</span><span class="timer-label">hrs</span></div>
        <span class="timer-sep" aria-hidden="true">:</span>
        <div class="timer-block"><span class="timer-num">${pad(m)}</span><span class="timer-label">min</span></div>
        <span class="timer-sep" aria-hidden="true">:</span>
        <div class="timer-block"><span class="timer-num">${pad(s)}</span><span class="timer-label">sec</span></div>`;
    }
    tick(); setInterval(tick, 1000);
  });
}

/* =============================================
   WISHLIST
   ============================================= */
const WL = {
  key: 'mjk-wishlist',
  get() { try { return JSON.parse(localStorage.getItem(this.key) || '[]'); } catch { return []; } },
  set(arr) { localStorage.setItem(this.key, JSON.stringify(arr)); },
  init() {
    const list = this.get();
    list.forEach(id => $$(`[data-wishlist-id="${id}"]`).forEach(b => b.classList.add('active')));
    on(document, 'click', e => {
      const btn = e.target.closest('[data-wishlist-id]');
      if (!btn) return;
      const id = btn.dataset.wishlistId;
      const wl = this.get();
      const i  = wl.indexOf(id);
      if (i > -1) {
        wl.splice(i, 1);
        btn.classList.remove('active');
        btn.textContent = '♡';
        showToast('Removed from wishlist');
      } else {
        wl.push(id);
        btn.classList.add('active');
        btn.textContent = '♥';
        showToast('♥ Added to wishlist');
      }
      this.set(wl);
    });
  }
};

/* =============================================
   CATEGORY FILTER
   ============================================= */
function initCatFilter() {
  const btns  = $$('.cat-btn');
  const cards = $$('.product-card');
  if (!btns.length) return;
  btns.forEach(btn => on(btn, 'click', () => {
    btns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const cat = btn.dataset.cat;
    cards.forEach(card => card.style.display = (cat === 'all' || card.dataset.cat === cat) ? '' : 'none');
  }));
}

/* =============================================
   COUPON
   ============================================= */
function initCoupon() {
  on($('[data-coupon-apply]'), 'click', () => {
    const input  = $('[data-coupon-input]');
    const msgEl  = $('[data-coupon-msg]');
    if (!input) return;
    const code = input.value.trim().toUpperCase();
    if (!code) { if (msgEl) { msgEl.style.color = 'var(--c-sale)'; msgEl.textContent = 'Enter a coupon code.'; } return; }
    if (code === 'MAJMA10' || code === 'WELCOME10') {
      if (msgEl) { msgEl.style.color = 'var(--c-ok)'; msgEl.textContent = '✓ Code applied! Discount at checkout.'; }
      showToast('✓ Coupon applied!');
    } else {
      if (msgEl) { msgEl.style.color = 'var(--c-sale)'; msgEl.textContent = 'Invalid code. Try MAJMA10.'; }
    }
  });
}

/* =============================================
   RECENTLY VIEWED
   ============================================= */
function trackRecentlyViewed() {
  const idEl = $('[data-product-id]');
  if (!idEl) return;
  const id = idEl.dataset.productId;
  if (!id) return;
  try {
    let rv = JSON.parse(localStorage.getItem('mjk-rv') || '[]');
    rv = rv.filter(i => i !== id);
    rv.unshift(id);
    localStorage.setItem('mjk-rv', JSON.stringify(rv.slice(0, 12)));
  } catch {}
}

/* =============================================
   SEARCH RESULT CSS (injected once)
   ============================================= */
function injectSearchStyles() {
  if ($('#mjk-sr-styles')) return;
  const s = document.createElement('style');
  s.id = 'mjk-sr-styles';
  s.textContent = `.sr-item{display:grid;grid-template-columns:48px 1fr;gap:.6rem;padding:.5rem .75rem;border-radius:6px;transition:background .15s;align-items:center;text-decoration:none}.sr-item:hover{background:var(--c-bg2)}.sr-img{width:48px;height:48px;object-fit:cover;border-radius:4px;background:var(--c-bg2)}.sr-name{font-size:.82rem;font-weight:600;color:var(--c-fg);line-height:1.3;margin:0 0 2px}.sr-price{font-size:.78rem;font-weight:700;color:var(--c-sale);margin:0}.sr-view-all{display:block;padding:.6rem .75rem;font-size:.8rem;font-weight:600;color:var(--c-accent);text-align:center;border-top:1px solid var(--c-border);margin-top:.25rem}.sr-view-all:hover{background:var(--c-bg2)}`;
  document.head.appendChild(s);
}

/* =============================================
   CART PAGE (standalone page)
   ============================================= */
function initCartPage() {
  const page = $('.cart-page');
  if (!page) return;
  // Qty buttons handled by Cart.pageChange via event delegation above
}

/* =============================================
   LEGACY COMPATIBILITY (old inline calls)
   ============================================= */
window.addToCartShopify = function(variantId, btn) {
  if (!btn) return;
  btn.dataset.atc = variantId;
  Cart.add(btn);
};
window.toggleWishlist = function(btn) {
  btn.classList.toggle('active');
  btn.textContent = btn.classList.contains('active') ? '♥' : '♡';
  showToast(btn.classList.contains('active') ? '♥ Added to wishlist!' : '♡ Removed from wishlist');
};
window.toggleSearch     = toggleSearch;
window.toggleMobileMenu = function() {
  const panel = $('#MobilePanel');
  const ham   = $('.ham-btn');
  if (!panel) return;
  const open = panel.classList.toggle('open');
  ham?.classList.toggle('open', open);
  if (open) openOverlay(); else closeOverlay();
};
window.changeQty = function(action, inputId) {
  const input = $('#' + (inputId || 'ProductQtyInput')) || $('[data-qty-input]');
  if (!input) return;
  const val = parseInt(input.value) || 1;
  input.value = action === 'plus' ? Math.min(val + 1, 99) : Math.max(val - 1, 1);
};
window.updateCartItem = async function(key, qty) {
  await fetch('/cart/change.js', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: key, quantity: Math.max(0, parseInt(qty) || 0) })
  });
  window.location.reload();
};
window.removeCartItem = async function(key) {
  await fetch('/cart/change.js', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ id: key, quantity: 0 })
  });
  window.location.reload();
};
window.switchImage = function(el, src) {
  $$('.product-thumb').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  const img = $('#MainProductImage');
  if (img) img.src = src;
};
window.applyCoupon = function() {
  const input = $('[data-coupon-input]') || $('.coupon-input');
  const msgEl = $('[data-coupon-msg]') || $('.coupon-msg');
  if (!input) return;
  const code = input.value.trim().toUpperCase();
  if (!code) { if (msgEl) { msgEl.style.color = 'var(--c-sale)'; msgEl.textContent = 'Enter a coupon code.'; } return; }
  if (code === 'MAJMA10' || code === 'WELCOME10') {
    if (msgEl) { msgEl.style.color = 'var(--c-ok)'; msgEl.textContent = '✓ Applied! Discount at checkout.'; }
    showToast('✓ Coupon applied!');
  } else {
    if (msgEl) { msgEl.style.color = 'var(--c-sale)'; msgEl.textContent = 'Invalid. Try MAJMA10 for 10% off.'; }
  }
};
window.showToast = showToast;

/* =============================================
   INIT
   ============================================= */
document.addEventListener('DOMContentLoaded', () => {
  Cart.init();
  initHeader();
  initPredictiveSearch();
  initAnimations();
  initLazy();
  initProductPage();
  initTimers();
  initCatFilter();
  initCoupon();
  initCartPage();
  WL.init();
  trackRecentlyViewed();
  injectSearchStyles();
});
